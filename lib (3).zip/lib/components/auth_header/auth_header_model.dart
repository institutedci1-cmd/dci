import 'package:d_c_i_teacher_app/flutter_flow/flutter_flow_util.dart';
import 'package:d_c_i_teacher_app/components/auth_header/auth_header_widget.dart' show AuthHeaderWidget;
import 'package:flutter/material.dart';

class AuthHeaderModel extends FlutterFlowModel<AuthHeaderWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
