class AppConstants {
  static const String instituteName = 'DCI Teachers';
  
  static const List<String> classOptions = [
    'Class 4',
    'Class 5',
    'Class 6',
    'Class 7',
    'Class 8',
    'Class 9',
    'Class 10'
  ];

  static const List<String> subjectOptions = [
    'English',
    'Marathi',
    'Science',
    'Math'
  ];

  static const List<String> teacherOptions = [
    'Ikram Sir',
    'Irfan Sir',
    'Seema Madam',
    'Suraj Sir'
  ];
}
